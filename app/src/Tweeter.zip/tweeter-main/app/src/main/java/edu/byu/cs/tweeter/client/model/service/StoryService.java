package edu.byu.cs.tweeter.client.model.service;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import edu.byu.cs.tweeter.client.model.service.backgroundTask.handler.HasMoreTaskHandler;
import edu.byu.cs.tweeter.client.model.service.observer.ListObserver;
import edu.byu.cs.tweeter.client.model.service.backgroundTask.GetFeedTask;
import edu.byu.cs.tweeter.model.domain.AuthToken;
import edu.byu.cs.tweeter.model.domain.Status;
import edu.byu.cs.tweeter.model.domain.User;

public class StoryService extends ExecuteService {
    public StoryService(){};

    public void getStory(AuthToken authToken, User user, int pageSize, Status lastStatus, ListObserver<Status> observer){
        GetFeedTask getFeedTask = new GetFeedTask(authToken, user, pageSize, lastStatus, new HasMoreTaskHandler<Status>(observer));
        execute(getFeedTask);
    }
}
