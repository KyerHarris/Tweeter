package edu.byu.cs.tweeter.client.presenter;

public interface View {
    void displayErrorMessage(String message);
}
